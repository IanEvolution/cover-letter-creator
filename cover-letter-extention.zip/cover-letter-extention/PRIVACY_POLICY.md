# Privacy Policy for Cover Letter Creator Chrome Extension

Your privacy is important to us. The Cover Letter Creator Chrome Extension does not collect, store, or sell any personal information.

- Resume files and job page content are processed locally in your browser and sent only to our secure backend for the sole purpose of generating a cover letter.
- No data is stored, tracked, or shared with third parties.
- We do not use your data for analytics, marketing, or any purpose other than generating your requested cover letter.

If you have any questions, contact us at ianholt839@gmail.com.
